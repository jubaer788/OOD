
package atm_systemj;

import java.util.Scanner;

public class Atm_SystemJ {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
                while(true){
        System.out.println("Enter username :");
        String n = s.nextLine();
        System.out.println("Enter password :");
        String p = s.nextLine();
        login l1 = new login();
        l1.setUname("j1");
        l1.setPass("12");
        String m = l1.getUname();
        String nn = l1.getPass();
        int x = n.compareTo(m);
        int y = p.compareTo(nn);
        if(x==0 && y==0){
            System.out.println("Login successfully");
            features f1 = new features();
            f1.option();
        }
        else{
            System.out.println("Invalid Password");
        }
    }
    }
    
}


package atm_systemj;

public class features {
    void option(){
        System.out.println("1.Deposit");
        System.out.println("1.withdraw");
        System.out.println("1.Check profile");
}
}
